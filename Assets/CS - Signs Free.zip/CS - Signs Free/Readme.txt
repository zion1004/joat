How to Use (2D):

• Add a sprite (Create > 2D > Sprite).
• Select your preferred sign from the Sprite selector (or drag it there from the Textures folder).

How To Use (3D):

• Drag a sign prefab to the preferred spot in the scene.
   or 
• Drag a sign prefab to a spot in the Hierarchy (this will put the sign at (0,0,0) unless it is nested in another object).

• (Optional) Drag a sign post and/or tab prefab into the sign in the Hierarchy folder.

This asset is a free version of the asset "US Road Signs Megapack". The full version has 550 more signs and is available here: http://u3d.as/1Edd